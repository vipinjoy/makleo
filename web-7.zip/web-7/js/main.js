


// FAQ Accordion
(function($) {
    $('.accordion > li:eq(0) a').addClass('active').next().slideDown();

    $('.accordion a').click(function(j) {
        var dropDown = $(this).closest('li').find('.ftext');

        $(this).closest('.accordion').find('.ftext').not(dropDown).slideUp();

        if ($(this).hasClass('active')) {
            $(this).removeClass('active');
        } else {
            $(this).closest('.accordion').find('a.active').removeClass('active');
            $(this).addClass('active');
        }

        dropDown.stop(false, true).slideToggle();

        j.preventDefault();
    });
})(jQuery); 


// Responsive menu


$('.mob-menu').click(function(event){

  $('body').toggleClass('open');
  event.stopPropagation();

})

$('.menu').click(function(event){

  event.stopPropagation();

})
$('.overlay').click(function(){
  if($('body').hasClass('open')){
    $('body').removeClass('open');
  }
});

$('.menu li:has(ul)').addClass('submenu');
$('.menu li:has(ul)').append( "<i></i>" );

$('.menu i').click(function(){
 $(this).parent('li').toggleClass('open');
})


// Home Banner sider


	$(document).ready(function(){
      $('.hb-slider').slick({
        arrows:true,
        fade:true,
        autoplay:true,
        autoplaySpeed:5000,
        dots:false,
        speed:1000
      });
    });


var wow = new WOW({
    offset: 250,
    mobile: false
});
wow.init();   



